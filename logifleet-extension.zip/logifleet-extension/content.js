// ============================================================
//  LogiFleet Driver Sync — content.js
//  Targets: https://backend.mrt.co.za/admin/drivers*
// ============================================================

const SUPABASE_URL     = 'https://brzrzlsueddmiozybqbr.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJyenJ6bHN1ZWRkbWlvenlicWJyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk5NTQ1NTMsImV4cCI6MjA5NTUzMDU1M30.3uFV1WEDv8XnPOTz1ExQ82eS22UPr5SZ98mm_2fopK4';

// ============================================================
//  1. INJECT THE SYNC BUTTON
// ============================================================

function injectButton() {
  // Avoid injecting twice on SPA navigations
  if (document.getElementById('logifleet-sync-btn')) return;

  const wrapper = document.createElement('div');
  wrapper.id = 'logifleet-sync-wrapper';
  wrapper.style.cssText = `
    position: fixed;
    top: 16px;
    right: 20px;
    z-index: 99999;
    display: flex;
    align-items: center;
    gap: 10px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  `;

  const btn = document.createElement('button');
  btn.id = 'logifleet-sync-btn';
  btn.textContent = '⬆ Sync Drivers to LogiFleet';
  btn.style.cssText = `
    background: #c75b2a;
    color: #fff;
    border: none;
    padding: 10px 18px;
    border-radius: 7px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 10px rgba(0,0,0,0.18);
    transition: background 0.15s, opacity 0.15s;
    white-space: nowrap;
  `;
  btn.onmouseover = () => btn.style.background = '#a84a22';
  btn.onmouseout  = () => btn.style.background = '#c75b2a';

  const status = document.createElement('span');
  status.id = 'logifleet-sync-status';
  status.style.cssText = `
    background: rgba(0,0,0,0.75);
    color: #fff;
    padding: 7px 13px;
    border-radius: 6px;
    font-size: 12px;
    display: none;
    max-width: 280px;
    line-height: 1.4;
  `;

  btn.addEventListener('click', runSync);
  wrapper.appendChild(btn);
  wrapper.appendChild(status);
  document.body.appendChild(wrapper);
}

// ============================================================
//  2. SCRAPE DRIVER RECORDS FROM THE PAGE
// ============================================================

function scrapeDrivers() {
  const drivers = [];
  const mediaBodyEls = document.querySelectorAll('div.media-body.pl-1');

  mediaBodyEls.forEach(el => {
    try {
      // --- profile_id & profile_name ---
      const anchor = el.querySelector('p.text-bold-600 a[href]');
      if (!anchor) return;

      const href = anchor.getAttribute('href') || '';
      const idMatch = href.match(/(\d+)\s*$/);
      if (!idMatch) return;
      const profile_id   = idMatch[1];
      const profile_name = anchor.textContent.trim();

      // --- email & cell_no from the muted paragraph ---
      const mutedP = el.querySelector('p.text-muted');
      if (!mutedP) return;

      const email  = extractTextAfterIcon(mutedP, 'ft-mail');
      const cell_no = extractTextAfterIcon(mutedP, 'ft-smartphone');

      drivers.push({ profile_id, profile_name, email, cell_no });
    } catch (err) {
      console.warn('[LogiFleet] Failed to parse a driver element:', err);
    }
  });

  return drivers;
}

/**
 * Walks the child nodes of a parent element and returns the trimmed text
 * that immediately follows the <i> tag with the given class.
 */
function extractTextAfterIcon(parentEl, iconClass) {
  const nodes = Array.from(parentEl.childNodes);
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    if (
      node.nodeType === Node.ELEMENT_NODE &&
      node.tagName === 'I' &&
      node.classList.contains(iconClass)
    ) {
      // Collect all consecutive text nodes after this icon
      let text = '';
      for (let j = i + 1; j < nodes.length; j++) {
        const next = nodes[j];
        // Stop when we hit the next icon
        if (next.nodeType === Node.ELEMENT_NODE && next.tagName === 'I') break;
        if (next.nodeType === Node.TEXT_NODE) text += next.textContent;
      }
      return text.trim() || null;
    }
  }
  return null;
}

// ============================================================
//  3. SEND TO SUPABASE (UPSERT)
// ============================================================

async function upsertDrivers(drivers, company_id) {
  const payload = drivers.map(d => ({
    profile_id:   d.profile_id,
    profile_name: d.profile_name,
    email:        d.email   || null,
    cell_no:      d.cell_no || null,
    company_id:   company_id || null,
    // status defaults to 'incomplete' via DB default — only set on INSERT
  }));

  const response = await fetch(`${SUPABASE_URL}/rest/v1/drivers`, {
    method: 'POST',
    headers: {
      'apikey':        SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type':  'application/json',
      'Prefer':        'resolution=merge-duplicates,return=representation'
      // merge-duplicates = upsert: inserts new, updates existing on profile_id conflict
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Supabase error ${response.status}: ${errText}`);
  }

  return await response.json();
}

// ============================================================
//  4. MAIN SYNC FLOW
// ============================================================

async function runSync() {
  const btn    = document.getElementById('logifleet-sync-btn');
  const status = document.getElementById('logifleet-sync-status');

  const setStatus = (msg, color = '#333') => {
    status.style.display = 'inline-block';
    status.style.background = color;
    status.textContent = msg;
  };

  // --- Ask for company_id ---
  const rawCompanyId = prompt(
    'LogiFleet Sync\n\nEnter the Company ID (UUID) to attach to these drivers.\nLeave blank to set company as None.',
    ''
  );

  // User cancelled the prompt entirely
  if (rawCompanyId === null) {
    setStatus('Sync cancelled.', 'rgba(80,80,80,0.85)');
    return;
  }

  const company_id = rawCompanyId.trim() || null;

  // --- Scrape ---
  btn.disabled = true;
  btn.style.opacity = '0.6';
  btn.textContent = 'Scraping...';
  setStatus('Scanning page for driver records…', 'rgba(0,0,0,0.75)');

  const drivers = scrapeDrivers();

  if (drivers.length === 0) {
    setStatus('⚠ No driver records found on this page.', 'rgba(160,100,0,0.9)');
    resetButton(btn);
    return;
  }

  setStatus(`Found ${drivers.length} drivers. Syncing to LogiFleet…`, 'rgba(0,0,0,0.75)');
  btn.textContent = 'Syncing…';

  // --- Upsert ---
  try {
    const result = await upsertDrivers(drivers, company_id);
    const count = Array.isArray(result) ? result.length : drivers.length;
    setStatus(`✓ ${count} drivers synced successfully!`, 'rgba(30,120,60,0.9)');
    console.log('[LogiFleet] Sync complete:', result);
  } catch (err) {
    setStatus(`✗ Sync failed: ${err.message}`, 'rgba(160,30,30,0.9)');
    console.error('[LogiFleet] Sync error:', err);
  } finally {
    resetButton(btn);
  }
}

function resetButton(btn) {
  btn.disabled = false;
  btn.style.opacity = '1';
  btn.textContent = '⬆ Sync Drivers to LogiFleet';
}

// ============================================================
//  5. INIT
// ============================================================

injectButton();
